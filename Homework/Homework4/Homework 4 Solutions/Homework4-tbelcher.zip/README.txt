Homework 4 — Taylor Belcher

Contents:
- hw4_solutions-tbelcher.pdf: compiled answers.
- Q2_CartPole.ipynb: three CartPole algorithms; requires cartpole_upstream/.
- Q4_Genetic_Algorithm.ipynb: executed genetic algorithm experiment.
- q2_results/ and q4_results/: measured results, configurations, and figures.

Extract the entire archive into one folder before opening the notebooks.
For Q2, follow the automatic CPU-only environment setup, select its kernel,
and run the notebook in order. Q4 can use the same environment and installs
scikit-opt if needed. Installation needs internet access. The saved Q2
experiment results are included even though its notebook has no saved cell
outputs. Q4 includes executed outputs. Re-running creates new result folders.

The virtual environment, model checkpoints, and LaTeX build files are omitted.
